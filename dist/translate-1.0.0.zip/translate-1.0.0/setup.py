#-*- coding: utf-8 -*-

from distutils.core import setup

setup(
	name = 'translate',
	version = '1.0.0',
	py_modules =['translate',],

)